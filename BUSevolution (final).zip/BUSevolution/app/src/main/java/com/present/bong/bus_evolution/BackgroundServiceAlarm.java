package com.present.bong.bus_evolution;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.BitmapFactory;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.support.v4.app.NotificationCompat;
import android.util.Log;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

//간편 알람을위한 클래스 백그라운드 에서 동작을위해 서비스를 상속
public class BackgroundServiceAlarm extends Service {
    MyCustomBusLineInfoAPIAdapter myCustomBusLineInfoAPIAdapter;
    ArrayList<BusLineInfoBean> busLineInfoList;
    String lineId, stopArrive, lineNum;
    Thread thread;
    int count = 0;
    boolean run = true;

    //서비스 시작 했을때 실행할 명령
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        //intent 값은 여기서 말곤 못받는거 같음 (확실하진않음)
        lineId = intent.getStringExtra("lineId");
        stopArrive = intent.getStringExtra("stopArrive");
        lineNum = intent.getStringExtra("lineNum");
        //작업을 반복할 쓰레드
        thread = new Thread(new Runnable() {
            @Override
            public void run() {
                    while (run) {
                        try {
                            xmlPaserThirdAlarm();
                            if(count == 7) break;
                        } catch (UnsupportedEncodingException e) {
                            e.printStackTrace();
                        }

                        myCustomBusLineInfoAPIAdapter =
                                new MyCustomBusLineInfoAPIAdapter(getApplicationContext(),
                                        R.layout.bus_line_info_list_row, busLineInfoList);

                        try {
                            Thread.sleep(1000 * 29);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
            }
        });
        thread.start();

    /*리턴을 뭘로해주냐에 따라 실행이 달라진다.
    1.START_STICKY: 를 사용 하면  시스템이 작동을 중지 시켜도 계속 돌아간다. 하지만 intent값이 초기화되서 널포인드 에러가 남
    2.START_NOT_STICKY: 이 Flag를 리턴하면, 강제로 종료 된 Service가 재시작 하지 않는다. 대신 시스템이 일정시간후에 쓰레드를 종료시켜
    Service를 쓰는 이유가 없어짐
    3.START_REDELIVER_INTENT: START_STICKY와 마찬가지로 Service가 종료 되었을 경우 시스템이 다시 Service를 재시작 시켜 주고
     intent 값을 그대로 유지 시켜 준다. startService() 메서드 호출시 Intent value값을 사용한 경우라면 해당 Flag를 사용해서 리턴값을 설정한다.
    */
        return START_REDELIVER_INTENT;
    }

    //파싱할 메소드
    public ArrayList<BusLineInfoBean> xmlPaserThirdAlarm() throws UnsupportedEncodingException {

        ArrayList<BusLineInfoBean> allList = new ArrayList<BusLineInfoBean>();

        String URLSTRING = URLEncoder.encode(lineId, "UTF-8");
        try {
            String key = "http://61.43.246.153/openapi-data/service/busanBIMS2/busInfoRoute?serviceKey=qtoPVWzzOaHE2p0loY9qiyWjAqQ%2FHPfkE3dZmm41%2FLOt9EBf3wB613JruaP8d27Jm0cJlwJE851k7v5UTG4hQQ%3D%3D&lineid="
                    + URLSTRING + " ";
            URL url = new URL(key);
            InputStream inputStream = url.openStream();
            XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
            XmlPullParser xmlPullParser = factory.newPullParser();
            xmlPullParser.setInput(new InputStreamReader(inputStream, "UTF-8"));
            int eventType = xmlPullParser.getEventType();
            BusLineInfoBean busLineInfo = null;
            while (eventType != XmlPullParser.END_DOCUMENT) {
                switch (eventType) {
                    case XmlPullParser.START_TAG:
                        String startTag = xmlPullParser.getName().trim();
                        if ("item".equals(startTag)) busLineInfo = new BusLineInfoBean();

                        if ("bstopIdx".equals(startTag))
                            if (busLineInfo != null)
                                busLineInfo.setBstopIdx(xmlPullParser.nextText());

                        if ("bstopnm".equals(startTag))
                            if (busLineInfo != null)
                                busLineInfo.setBstopnm(xmlPullParser.nextText());

                        if ("carNo".equals(startTag))
                            if (busLineInfo != null) {
                                busLineInfo.setCarNo(xmlPullParser.nextText());
                                if (busLineInfo.getBstopIdx().equals(stopArrive)) {
                                    NotificationSomethings();
                                    count++;
                                }

                            }
                        if ("crowded".equals(startTag))
                            if (busLineInfo != null)
                                busLineInfo.setCrowded(xmlPullParser.nextText());

                        break;
                    case XmlPullParser.END_TAG:
                        String endTag = xmlPullParser.getName().trim();
                        if ("item".equals(endTag)) allList.add(busLineInfo);
                        break;
                }
                eventType = xmlPullParser.next();
            }

        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e) {
            e.printStackTrace();
        }

        return allList;
    }

    //알람을 울려줄 메소드
    public void NotificationSomethings() {

        Resources res = getResources();

        Intent notificationIntentAlarm = new Intent(this, NotificationEventAlarm.class);

        PendingIntent contentIntentAlarm = PendingIntent.getActivity(this, 0, notificationIntentAlarm, PendingIntent.FLAG_UPDATE_CURRENT);
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this);


        builder.setContentTitle(lineNum + "번버스 왔습니다 ")
                .setContentText(lineNum + "번버스 왔어요 뿌~~~~~")
                .setTicker(lineNum + "번버스 왔어요 뿌~~~~~")
                .setSmallIcon(R.drawable.busmake)
                .setLargeIcon(BitmapFactory.decodeResource(res, R.drawable.prometheus_bro_icon))
                .setContentIntent(contentIntentAlarm)
                .setAutoCancel(true)
                .setWhen(System.currentTimeMillis())
                .setDefaults(Notification.DEFAULT_ALL);


        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
            builder.setCategory(Notification.CATEGORY_MESSAGE)
                    .setPriority(Notification.PRIORITY_HIGH)
                    .setVisibility(Notification.VISIBILITY_PUBLIC);
        }

        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        nm.notify(4567, builder.build());


    }

    //종료되었을 때의 실행
    @Override
    public void onDestroy() {

        super.onDestroy();
        run = false;
        BackgroundServiceAlarm.this.stopSelf();
        Log.i("Destory", "onDestroy:~~~~~~~~~ ");
    }

    //몰래 숨어있는 뭐 그런 기능
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {

        return null;
    }

}
