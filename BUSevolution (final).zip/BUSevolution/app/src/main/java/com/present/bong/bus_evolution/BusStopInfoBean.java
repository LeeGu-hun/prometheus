package com.present.bong.bus_evolution;
//버스정류장 정보 빈
public class BusStopInfoBean {
    String lineNo;
    String carNo1;
    String station1;
    String min1;
    String crowded1;
    String carNo2;
    String station2;
    String min2;
    String crowded2;

    public String getLineNo() {
        return lineNo;
    }

    public void setLineNo(String lineNo) {
        this.lineNo = lineNo;
    }

    public String getCarNo1() {
        return carNo1;
    }

    public void setCarNo1(String carNo1) {
        this.carNo1 = carNo1;
    }

    public String getStation1() {
        return station1;
    }

    public void setStation1(String station1) {
        this.station1 = station1;
    }

    public String getMin1() {
        return min1;
    }

    public void setMin1(String min1) {
        this.min1 = min1;
    }

    public String getCrowded1() {
        return crowded1;
    }

    public void setCrowded1(String crowded1) {
        this.crowded1 = crowded1;
    }

    public String getCarNo2() {
        return carNo2;
    }

    public void setCarNo2(String carNo2) {
        this.carNo2 = carNo2;
    }

    public String getStation2() {
        return station2;
    }

    public void setStation2(String station2) {
        this.station2 = station2;
    }

    public String getMin2() {
        return min2;
    }

    public void setMin2(String min2) {
        this.min2 = min2;
    }

    public String getCrowded2() {
        return crowded2;
    }

    public void setCrowded2(String crowded2) {
        this.crowded2 = crowded2;
    }
}
