package com.present.bong.bus_evolution;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;
//버스번호를 받을 어댑터
public class MyCustomBusNumAPIAdapter extends BaseAdapter {
    Context ctx;
    int layout;
    ArrayList<BusNumBean>list;
    LayoutInflater inflater;

    public MyCustomBusNumAPIAdapter(Context ctx, int layout, ArrayList<BusNumBean> list) {
        this.ctx = ctx;
        this.layout = layout;
        this.list = list;
        this.inflater = (LayoutInflater)ctx.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if(convertView == null)
            convertView = inflater.inflate(layout,parent,false);

        TextView buslinenum = (TextView)convertView.findViewById(R.id.buslinenum);
        TextView bustype = (TextView)convertView.findViewById(R.id.bustype);
        TextView endpoint = (TextView)convertView.findViewById(R.id.endpoint);
        TextView endtime = (TextView)convertView.findViewById(R.id.endtime);
        TextView firsttime = (TextView)convertView.findViewById(R.id.firsttime);
        TextView startpoint = (TextView)convertView.findViewById(R.id.startpoint);
        TextView lineId = (TextView)convertView.findViewById(R.id.lineId);


        BusNumBean busNum = list.get(position);
        //이부분에서 setText에 문자를 넣어놓으면 없을 시에 null값이뜬다.
        buslinenum.setText(busNum.getBuslinenum()+"번  ");
        bustype.setText("["+busNum.getBustype()+"]  ");
        endpoint.setText("종점:  "+busNum.getEndpoint()+"  ");
        endtime.setText("막차시간:  "+busNum.getEndtime()+"  ");
        firsttime.setText("첫차시간:  "+busNum.getFirsttime()+"  ");
        startpoint.setText("출발점:  "+busNum.getStartpoint()+"  ");
        lineId.setText(busNum.getLineId());


        return convertView;
    }
}
