package com.present.bong.bus_evolution;

import android.app.Activity;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;


public class NotificationEventBusAlarm  extends Activity {
    Button busCancelButton;
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.notification_bus);
        busCancelButton = findViewById(R.id.notificationBusButton);

        busCancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent2 = new Intent(NotificationEventBusAlarm.this, BackgroundServiceAlarm.class);
                Intent intentBusAlarm2 = new Intent(NotificationEventBusAlarm.this, BackgroundServiceBusAlarm.class);
                stopService(intent2);
                stopService(intentBusAlarm2);
                Toast.makeText(getApplicationContext(), "알람종료완료 ", Toast.LENGTH_SHORT).show();
            }
        });
        CharSequence s = "전달 받은 값은 ";
        int id=0;

        Bundle extras = getIntent().getExtras();
        if (extras == null) {
            s = "error";
        }



        NotificationManager nmbus =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        //노티피케이션 제거

        nmbus.cancel(id);
    }
}


