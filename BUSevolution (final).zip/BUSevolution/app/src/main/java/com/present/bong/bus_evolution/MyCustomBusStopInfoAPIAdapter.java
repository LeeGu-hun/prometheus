package com.present.bong.bus_evolution;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;
//버스 정류장 상세정보를 받을 어댑터
public class MyCustomBusStopInfoAPIAdapter extends BaseAdapter {
    Context ctx;
    int layout;
    ArrayList<BusStopInfoBean> list;
    LayoutInflater inflater;

    public MyCustomBusStopInfoAPIAdapter(Context ctx, int layout, ArrayList<BusStopInfoBean> list) {
        this.ctx = ctx;
        this.layout = layout;
        this.list = list;
        this.inflater = (LayoutInflater)ctx.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if(convertView == null)
            convertView = inflater.inflate(layout,parent,false);

        TextView lineNo1 = (TextView)convertView.findViewById(R.id.buslineNo1);
        TextView carNo1 = (TextView)convertView.findViewById(R.id.buscarNo1);
        TextView station1 = (TextView)convertView.findViewById(R.id.busstation1);
        TextView min1 = (TextView)convertView.findViewById(R.id.busmin1);
        TextView crowded1 = (TextView)convertView.findViewById(R.id.buscrowded1);
        TextView lineNo2 = (TextView)convertView.findViewById(R.id.buslineNo2);
        TextView carNo2 = (TextView)convertView.findViewById(R.id.buscarNo2);
        TextView station2 = (TextView)convertView.findViewById(R.id.busstation2);
        TextView min2 = (TextView)convertView.findViewById(R.id.busmin2);
        TextView crowded2 = (TextView)convertView.findViewById(R.id.buscrowded2);


        BusStopInfoBean busStopInfo = list.get(position);
        //이부분에서 setText에 문자를 넣어놓으면 없을 시에 null값이뜬다.
        lineNo1.setText(busStopInfo.getLineNo()+"번  ");
        carNo1.setText(busStopInfo.getCarNo1());
        station1.setText(busStopInfo.getStation1());
        min1.setText(busStopInfo.getMin1());
        crowded1.setText(busStopInfo.getCrowded1());
        lineNo2.setText(busStopInfo.getLineNo()+"번  ");
        carNo2.setText(busStopInfo.getCarNo2());
        station2.setText(busStopInfo.getStation2());
        min2.setText(busStopInfo.getMin2());
        crowded2.setText(busStopInfo.getCrowded2());

        return convertView;
    }
}