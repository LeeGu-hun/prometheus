package com.present.bong.bus_evolution;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;
//버스노선정보를 받을 어댑터
public class MyCustomBusLineInfoAPIAdapter extends BaseAdapter {
    Context ctx;
    int layout;
    ArrayList<BusLineInfoBean>list;
    LayoutInflater inflater;

    public MyCustomBusLineInfoAPIAdapter(Context ctx, int layout, ArrayList<BusLineInfoBean> list) {
        this.ctx = ctx;
        this.layout = layout;
        this.list = list;
        this.inflater = (LayoutInflater)ctx.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if(convertView == null)
            convertView = inflater.inflate(layout,parent,false);

        TextView bstopIdx = (TextView)convertView.findViewById(R.id.bstopIdx);
        TextView bstopnm = (TextView)convertView.findViewById(R.id.bstopnm);
        TextView carNo = (TextView)convertView.findViewById(R.id.carNo);
        TextView crowded = (TextView)convertView.findViewById(R.id.crowded);


        BusLineInfoBean busLineInfo = list.get(position);
        //이부분에서 setText에 문자를 넣어놓으면 없을 시에 null값이뜬다.
        bstopIdx.setText(busLineInfo.getBstopIdx()+"  ");
        bstopnm.setText("["+busLineInfo.getBstopnm()+"]   ");
        carNo.setText(busLineInfo.getCarNo());
        crowded.setText(busLineInfo.getCrowded());

        return convertView;
    }
}
