package com.present.bong.bus_evolution;

public class CrowdedBean {
    private  String carNo;
    private  int crowded;

    public String getCarNo() {
        return carNo;
    }

    public void setCarNo(String carNo) {
        this.carNo = carNo;
    }

    public int getCrowded() {
        return crowded;
    }

    public void setCrowded(int crowded) {
        this.crowded = crowded;
    }

}

