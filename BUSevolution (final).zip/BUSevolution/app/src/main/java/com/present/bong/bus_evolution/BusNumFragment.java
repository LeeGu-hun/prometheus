package com.present.bong.bus_evolution;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

//버스 번호를 검색 하는 플레그먼트
public class BusNumFragment extends android.support.v4.app.Fragment{
    ListView BusNumListView;
    Button btnsendBus;
    MyCustomBusNumAPIAdapter myCustomBusNumAPIAdapter;
    ArrayList<BusNumBean> busNumlist;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        //플레그 먼트에서는 바로 findViewById를 바로 쓸수 없다 view 객체 생성후 사용 가능하다
        View view = inflater.inflate(R.layout.bus_num_search, container, false);
        BusNumListView = view.findViewById(R.id.listBusNum);
        btnsendBus = view.findViewById(R.id.btnSendBus);
        btnsendBus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendBus();
                EditText editBusNum = getView().findViewById(R.id.editBusNum);
                //플레그먼트에서는 엑티비티의 메소드를 사용 못한다 사용하고 싶을땐 getActivity() 사용하면된다.
                //검색한후 키보드 를 소프트하게 없애고 싶을때 쓴다
                InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(editBusNum.getWindowToken(), 0);
                //리스트 아이템을 클릭하면 노선 검색액티비티로 이동 시킨다
                BusNumListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view,
                                            int position, long id) {
                        BusNumBean busNum = (BusNumBean) myCustomBusNumAPIAdapter.getItem(position);
                        Intent intent = new Intent(getActivity().getApplicationContext(),BusLineInfoActivity.class);
                        intent.putExtra("lineid", String.valueOf(busNum.getLineId()));
                        intent.putExtra("lineNum", String.valueOf(busNum.getBuslinenum()));
                        startActivity(intent);
                    }
                });
            }
        });
        return view;
    }
    //버스번호 파싱 스레드 (getActivity().runOnUiThread)
    public void sendBus() {

        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    busNumlist = BusAPIPaser();
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }
                getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        myCustomBusNumAPIAdapter =
                                new MyCustomBusNumAPIAdapter(getActivity().getApplicationContext(),
                                        R.layout.busnum_list_row, busNumlist);
                        BusNumListView.setAdapter(myCustomBusNumAPIAdapter);
                    }
                });
            }
        });
        thread.start();
    }
    //번호 파싱 메소드
    public ArrayList<BusNumBean> BusAPIPaser() throws UnsupportedEncodingException {
        EditText editBusNum = getView().findViewById(R.id.editBusNum);

        String value1 = editBusNum.getText().toString();
//        Log.i(value1, value1);
        String URLSTRING = URLEncoder.encode(value1, "UTF-8");
        ArrayList<BusNumBean> busList = new ArrayList<BusNumBean>();
        try {
            String key = "http://61.43.246.153/openapi-data/service/busanBIMS2/busInfo?serviceKey=qtoPVWzzOaHE2p0loY9qiyWjAqQ%2FHPfkE3dZmm41%2FLOt9EBf3wB613JruaP8d27Jm0cJlwJE851k7v5UTG4hQQ%3D%3D&lineno="
                    + URLSTRING + " ";
            URL url = new URL(key);
            InputStream inputStream = url.openStream();
            XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
            XmlPullParser xmlPullParser = factory.newPullParser();
            xmlPullParser.setInput(new InputStreamReader(inputStream, "UTF-8"));
            int eventType = xmlPullParser.getEventType();
            BusNumBean busNum = null;
            while (eventType != XmlPullParser.END_DOCUMENT) {
                switch (eventType) {
                    case XmlPullParser.START_TAG:
                        String startTag = xmlPullParser.getName().trim();
                        if ("item".equals(startTag)) busNum = new BusNumBean();

                        if ("buslinenum".equals(startTag))
                            if (busNum != null)
                                busNum.setBuslinenum(xmlPullParser.nextText());

                        if ("bustype".equals(startTag))
                            if (busNum != null)
                                busNum.setBustype(xmlPullParser.nextText());

                        if ("endpoint".equals(startTag))
                            if (busNum != null)
                                busNum.setEndpoint(xmlPullParser.nextText());

                        if ("endtime".equals(startTag))
                            if (busNum != null)
                                busNum.setEndtime(xmlPullParser.nextText());

                        if ("firsttime".equals(startTag))
                            if (busNum != null)
                                busNum.setFirsttime(xmlPullParser.nextText());

                        if ("startpoint".equals(startTag))
                            if (busNum != null)
                                busNum.setStartpoint(xmlPullParser.nextText());

                        if ("lineId".equals(startTag))
                            if (busNum != null)
                                busNum.setLineId(xmlPullParser.nextText());
                        break;
                    case XmlPullParser.END_TAG:
                        String endTag = xmlPullParser.getName().trim();
                        if ("item".equals(endTag)) busList.add(busNum);
                        break;
                }
                eventType = xmlPullParser.next();
            }

        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e) {
            e.printStackTrace();
        }

        return busList;
    }


}
