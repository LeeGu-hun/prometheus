package com.present.bong.bus_evolution;

import android.app.Activity;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;


public class NotificationEventAlarm extends Activity {
    Button cancelButton;
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.notification);

        cancelButton = findViewById(R.id.notificationButton);
        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1 = new Intent(NotificationEventAlarm.this, BackgroundServiceAlarm.class);
                Intent intentBusAlarm = new Intent(NotificationEventAlarm.this, BackgroundServiceBusAlarm.class);
                stopService(intent1);
                stopService(intentBusAlarm);
                Toast.makeText(getApplicationContext(), "알람종료완료 ", Toast.LENGTH_SHORT).show();
            }
        });
        CharSequence s = "전달 받은 값은 ";
        int id=0;

        Bundle extras = getIntent().getExtras();
        if (extras == null) {
            s = "error";
        }


        NotificationManager nm =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        //노티피케이션 제거
        nm.cancel(id);
    }
}
