package com.present.bong.bus_evolution;

//알람 파싱을 위한 빈
public class BusAlarmBean {

    String carno,bstopstart,bstopArrive,nodeId;

    public String getCarno() {
        return carno;
    }

    public void setCarno(String carno) {
        this.carno = carno;
    }

    public String getBstopstart() {
        return bstopstart;
    }

    public void setBstopstart(String bstopstart) {
        this.bstopstart = bstopstart;
    }

    public String getBstopArrive() {
        return bstopArrive;
    }

    public void setBstopArrive(String bstopArrive) {
        this.bstopArrive = bstopArrive;
    }

    public String getNodeId() { return nodeId; }

    public void setNodeId(String nodeId) { this.nodeId = nodeId; }
}
