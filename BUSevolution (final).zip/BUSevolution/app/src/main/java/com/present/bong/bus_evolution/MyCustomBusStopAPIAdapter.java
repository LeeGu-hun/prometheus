package com.present.bong.bus_evolution;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;
//버스정류장을 받을 어댑터
public class MyCustomBusStopAPIAdapter extends BaseAdapter {
    Context ctx;
    int layout;
    ArrayList<BusStopBean>list;
    LayoutInflater inflater;

    public MyCustomBusStopAPIAdapter(Context ctx, int layout, ArrayList<BusStopBean> list) {
        this.ctx = ctx;
        this.layout = layout;
        this.list = list;
        this.inflater = (LayoutInflater)ctx.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if(convertView == null)
            convertView = inflater.inflate(layout,parent,false);

        TextView title = (TextView)convertView.findViewById(R.id.textTitle);
        TextView bstopArsno = (TextView)convertView.findViewById(R.id.textbstopArsno);
        TextView bstopId = (TextView)convertView.findViewById(R.id.textbstopId);
        TextView gpsX = (TextView)convertView.findViewById(R.id.textgpsX);
        TextView gpsY = (TextView)convertView.findViewById(R.id.textgpsY);
        TextView stoptype = (TextView)convertView.findViewById(R.id.textstoptype);



        BusStopBean busStop = list.get(position);
        //이부분에서 setText에 문자를 넣어놓으면 없을 시에 null값이뜬다.
        title.setText(busStop.getTitle());
        bstopArsno.setText(busStop.getBstopArsno());
        bstopId.setText(busStop.getBstopId());
        gpsX.setText(busStop.getGpsX());
        gpsY.setText(busStop.getGpsY());
        stoptype.setText(busStop.getStoptype());

        return convertView;
    }
}