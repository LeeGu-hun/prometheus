package com.present.bong.bus_evolution;
//버스번호 빈
public class BusNumBean {
    String buslinenum;
    String bustype;
    String endpoint;
    String endtime;
    String firsttime;
    String lineId;
    String startpoint;

    public String getBuslinenum() {
        return buslinenum;
    }

    public void setBuslinenum(String buslinenum) {
        this.buslinenum = buslinenum;
    }

    public String getBustype() {
        return bustype;
    }

    public void setBustype(String bustype) {
        this.bustype = bustype;
    }

    public String getEndpoint() {
        return endpoint;
    }

    public void setEndpoint(String endpoint) {
        this.endpoint = endpoint;
    }

    public String getEndtime() {
        return endtime;
    }

    public void setEndtime(String endtime) {
        this.endtime = endtime;
    }

    public String getFirsttime() {
        return firsttime;
    }

    public void setFirsttime(String firsttime) {
        this.firsttime = firsttime;
    }

    public String getLineId() {
        return lineId;
    }

    public void setLineId(String lineId) {
        this.lineId = lineId;
    }

    public String getStartpoint() {
        return startpoint;
    }

    public void setStartpoint(String startpoint) {
        this.startpoint = startpoint;
    }
}
