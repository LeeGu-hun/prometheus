package com.present.bong.bus_evolution;


import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;
//도움말을 띄어주기 위한 액티비티
public class BusHelperActivity extends Activity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bus_alarm_helper);

    }
}
