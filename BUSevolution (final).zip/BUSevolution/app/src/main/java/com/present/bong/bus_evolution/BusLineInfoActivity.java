package com.present.bong.bus_evolution;


import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.google.gson.Gson;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

//버스노선 상세정보 액티비티
public class BusLineInfoActivity extends Activity {
    ListView BusLineInfoListView;
    MyCustomBusLineInfoAPIAdapter myCustomBusLineInfoAPIAdapter;
    ArrayList<BusLineInfoBean> busLineInfoList;
    String carno, bstopstart, bstopArrive,nodeId;
    BusAlarmBean busAlarm = new BusAlarmBean();
    CrowdedBean crowdeddata = new CrowdedBean();
    //액티비티 실행시 실행되는 메소드 Ui설정 가능
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bus_line_info);

        //이사온 인텐트를 받는다.
        Intent intent = new Intent(this.getIntent());
        final String lineIdsend = intent.getStringExtra("lineid");
        final String lineNumsend = intent.getStringExtra("lineNum");
        //쓰레드 실행
        send();

        //여기서부터는  AlertDialog 설정
        final CharSequence[] items = {"출발(버스선택)", "도착", "정거장알림(간편알람)", "알람종료"};
        AlertDialog.Builder builder = new AlertDialog.Builder(this);     // 여기서 this는 Activity의 this
        builder.setTitle("알람 설정").setItems(items, new DialogInterface.OnClickListener() {    // 목록 클릭시 설정

            public void onClick(DialogInterface dialog, int index) {
                if (index == 0) {
                    //출발(버스선택)은 버스를 선택할때만 나온다
                    Toast.makeText(getApplicationContext(), "출발설정완료", Toast.LENGTH_SHORT).show();
                    busAlarm.setCarno(carno);
                    busAlarm.setBstopstart(bstopstart);

                } else if (index == 1) {
                    busAlarm.setBstopArrive(bstopArrive);
                    busAlarm.setNodeId(nodeId);
                    if (busAlarm.getBstopstart() != null) {
                        int a = Integer.parseInt(busAlarm.getBstopArrive());
                        int b = Integer.parseInt(busAlarm.getBstopstart());
                        //도착지를 출발지보다 앞에 선택했을 시에 실행
                        if (a - b > 0) {
                /*intent를 서비스로 이사보낸다.주의 해야할점은 서비스로 값을 넘길경우 현재 제어권자 PackageContext를 현재의 액티비티로
                 명시 해줘야된다 getApplicationContext()를 사용 할시 제어권자가 모호해 지기 때문에 Service에서 intent값을 받지 못한다*/
                            Intent intentBusAlarm = new Intent(BusLineInfoActivity.this, BackgroundServiceBusAlarm.class);
                            String nodeId = busAlarm.getNodeId();
                            String carno = busAlarm.getCarno().substring(3);
                            Log.i("logi", "onClickcarno: "+carno);
                            intentBusAlarm.putExtra("lineNum", lineNumsend);
                            intentBusAlarm.putExtra("nodeId", nodeId);
                            intentBusAlarm.putExtra("carno", carno);
                            startService(intentBusAlarm);
                            Toast.makeText(getApplicationContext(), "알람설정완료(앱을 완전히 종료하지 마세요.)", Toast.LENGTH_LONG).show();
                        } else {
                            Toast.makeText(getApplicationContext(), "알람설정실패(도착지가 출발지보다 앞에 있습니다.)", Toast.LENGTH_LONG).show();
                        }
                    } else {
                        Toast.makeText(getApplicationContext(), "알람설정실패(출발지를 먼저 선택 하세요.)", Toast.LENGTH_LONG).show();
                    }
                } else if (index == 2) {
                    busAlarm.setBstopArrive(bstopArrive);
                    String result = busAlarm.getBstopArrive();
                    Intent intent1 = new Intent(BusLineInfoActivity.this, BackgroundServiceAlarm.class);
                    intent1.putExtra("lineId", lineIdsend);
                    intent1.putExtra("stopArrive", result);
                    intent1.putExtra("lineNum", lineNumsend);
                    startService(intent1);
                    Toast.makeText(getApplicationContext(), "알람설정완료 최대4대 까지 알림(앱을 완전히 종료하지 마세요.) ", Toast.LENGTH_SHORT).show();
                } else {
                    //서비스 취소
                    Intent intent1 = new Intent(BusLineInfoActivity.this, BackgroundServiceAlarm.class);
                    Intent intentBusAlarm = new Intent(BusLineInfoActivity.this, BackgroundServiceBusAlarm.class);
                    stopService(intent1);
                    stopService(intentBusAlarm);
                    Toast.makeText(getApplicationContext(), "알람취소완료 ", Toast.LENGTH_SHORT).show();
                }
            }
        });
        final AlertDialog dialog = builder.create(); // 알림창 객체 생성


        final CharSequence[] items2 = {"도착", "정거장알림(간편알람)", "알람종료"};
        AlertDialog.Builder builder2 = new AlertDialog.Builder(this);

        builder2.setTitle("알람받을 정류장 선택").setItems(items2, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int index) {

                if (index == 0) {
                    busAlarm.setBstopArrive(bstopArrive);
                    busAlarm.setNodeId(nodeId);
                    if (busAlarm.getBstopstart() != null) {
                        int a = Integer.parseInt(busAlarm.getBstopArrive());
                        int b = Integer.parseInt(busAlarm.getBstopstart());

                        if (a - b > 0) {
                            Intent intentBusAlarm = new Intent(BusLineInfoActivity.this, BackgroundServiceBusAlarm.class);
                            String nodeId = busAlarm.getNodeId();
                            String carno = busAlarm.getCarno().substring(3);
                            Log.i("logi", "onClickcarno: "+carno);
                            intentBusAlarm.putExtra("lineNum", lineNumsend);
                            intentBusAlarm.putExtra("nodeId", nodeId);
                            intentBusAlarm.putExtra("carno", carno);
                            startService(intentBusAlarm);
                            Toast.makeText(getApplicationContext(), "알람설정완료(앱을 완전히 종료하지 마세요.)", Toast.LENGTH_LONG).show();
                        } else {
                            Toast.makeText(getApplicationContext(), "알람설정실패(도착지가 출발지보다 앞에 있습니다.)", Toast.LENGTH_LONG).show();
                        }
                    } else {
                        Toast.makeText(getApplicationContext(), "알람설정실패(출발지를 먼저 선택 하세요.)", Toast.LENGTH_LONG).show();
                    }
                } else if (index == 1) {
                    busAlarm.setBstopArrive(bstopArrive);
                    String result = busAlarm.getBstopArrive();
                    Intent intent1 = new Intent(BusLineInfoActivity.this, BackgroundServiceAlarm.class);
                    intent1.putExtra("lineId", lineIdsend);
                    intent1.putExtra("stopArrive", result);
                    intent1.putExtra("lineNum", lineNumsend);
                    startService(intent1);
                    Toast.makeText(getApplicationContext(), "알람설정완료 최대4대 까지 알림(앱을 완전히 종료하지 마세요.) ", Toast.LENGTH_SHORT).show();
                } else {
                    Intent intent1 = new Intent(BusLineInfoActivity.this, BackgroundServiceAlarm.class);
                    Intent intentBusAlarm = new Intent(BusLineInfoActivity.this, BackgroundServiceBusAlarm.class);

                    stopService(intent1);
                    stopService(intentBusAlarm);
                    Toast.makeText(getApplicationContext(), "알람취소완료 ", Toast.LENGTH_SHORT).show();
                }
            }
        });

        final AlertDialog dialog2 = builder2.create();

        //보여줄 리스트 뷰생성
        BusLineInfoListView = (ListView) findViewById(R.id.buslineinfoList);
        BusLineInfoListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                BusLineInfoBean busLineInfo = (BusLineInfoBean) myCustomBusLineInfoAPIAdapter.getItem(position);


                bstopArrive = String.valueOf(busLineInfo.getBstopIdx());
                Log.i(bstopArrive, "onItemClick: " + bstopArrive);
                nodeId = String.valueOf(busLineInfo.getNodeId());
                carno = String.valueOf(busLineInfo.getCarNo());
                if (!carno.equals("null")) {

                    bstopstart = String.valueOf(busLineInfo.getBstopIdx());
                    dialog.show();

                } else {
                    dialog2.show();
                }
            }
        });
    }
//파싱할 쓰레드 Ui를 변경 해준다
    public void send() {
        final Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {

                try {
                    busLineInfoList = xmlPaser();
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        myCustomBusLineInfoAPIAdapter =
                                new MyCustomBusLineInfoAPIAdapter(getApplicationContext(),
                                        R.layout.bus_line_info_list_row, busLineInfoList);
                        BusLineInfoListView.setAdapter(myCustomBusLineInfoAPIAdapter);

                    }
                });
            }
        });
        thread.start();
    }
/* ui를 실시간으로 변경 해주는 쓰레드 이나 백그라운드에서는 돌아가지 않아서 주석 처리 나중에 쓰일수도..
    public void sendAlarm() {
        final Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                while (true) {
                    try {
                        busLineInfoList = xmlPaserAlarm();
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            myCustomBusLineInfoAPIAdapter =
                                    new MyCustomBusLineInfoAPIAdapter(getApplicationContext(),
                                            R.layout.bus_line_info_list_row, busLineInfoList);
                            BusLineInfoListView.setAdapter(myCustomBusLineInfoAPIAdapter);

                        }
                    });
                    try {
                        Thread.sleep(1000 * 60);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
        thread.start();
    }

    public void sendThirdAlarm() {
        final Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                while (true) {
                    try {
                        busLineInfoList = xmlPaserThirdAlarm();
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            myCustomBusLineInfoAPIAdapter =
                                    new MyCustomBusLineInfoAPIAdapter(getApplicationContext(),
                                            R.layout.bus_line_info_list_row, busLineInfoList);
                            BusLineInfoListView.setAdapter(myCustomBusLineInfoAPIAdapter);

                        }
                    });
                    try {
                        Thread.sleep(1000 * 60);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
        thread.start();
    }
*/
//파싱 메서드
    public ArrayList<BusLineInfoBean> xmlPaser() throws UnsupportedEncodingException {
        Intent intent = new Intent(this.getIntent());
        String lineId = intent.getStringExtra("lineid");
        ArrayList<BusLineInfoBean> allList = new ArrayList<BusLineInfoBean>();

        String URLSTRING = URLEncoder.encode(lineId, "UTF-8");
        try {
            String key = "http://61.43.246.153/openapi-data/service/busanBIMS2/busInfoRoute?serviceKey=qtoPVWzzOaHE2p0loY9qiyWjAqQ%2FHPfkE3dZmm41%2FLOt9EBf3wB613JruaP8d27Jm0cJlwJE851k7v5UTG4hQQ%3D%3D&lineid="
                    + URLSTRING + " ";
            URL url = new URL(key);
            InputStream inputStream = url.openStream();
            XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
            XmlPullParser xmlPullParser = factory.newPullParser();
            xmlPullParser.setInput(new InputStreamReader(inputStream, "UTF-8"));
            int eventType = xmlPullParser.getEventType();
            BusLineInfoBean busLineInfo = null;
            while (eventType != XmlPullParser.END_DOCUMENT) {
                switch (eventType) {
                    case XmlPullParser.START_TAG:
                        String startTag = xmlPullParser.getName().trim();
                        if ("item".equals(startTag)) busLineInfo = new BusLineInfoBean();

                        if ("bstopIdx".equals(startTag))
                            if (busLineInfo != null)
                                busLineInfo.setBstopIdx(xmlPullParser.nextText());

                        if ("bstopnm".equals(startTag))
                            if (busLineInfo != null)
                                busLineInfo.setBstopnm(xmlPullParser.nextText());

                        if ("carNo".equals(startTag))
                            if (busLineInfo != null) {
                                busLineInfo.setCarNo(xmlPullParser.nextText());
                                if (busLineInfo.getCarNo().equals("운행중버스")) {
                                    try {
                                        Task networkTask = new Task();

                                        Map<String, String> params = new HashMap<String, String>();
                                        params.put("carno", "2632");
                                        String test =  networkTask.execute(params).get();
                                        Gson gson = new Gson();
                                        crowdeddata = gson.fromJson(test, CrowdedBean.class);
                                       int crowdedTest = crowdeddata.getCrowded();

                                       Log.i("xammlpas", "crowdedTest: "+crowdedTest);
                                        String crowded = null;
                                        if (crowdedTest < 20) {
                                            crowded =   "[쾌적]";
                                        } else if (crowdedTest < 30) {
                                            crowded =   "[보통]";
                                        } else {
                                            crowded =   "[혼잡]";
                                        }
                                        busLineInfo.setCrowded(crowded);
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                } else {
                                    int crowdedTest = (int) (Math.random() * 45);
                                    String crowded = null;
                                    if (crowdedTest < 20) {
                                        crowded = "   [쾌적]";
                                    } else if (crowdedTest < 30) {
                                        crowded = "   [보통]";
                                    } else {
                                        crowded = "   [혼잡]";
                                    }
                                    busLineInfo.setCrowded(crowded);
                                }
                            }
                        if ("crowded".equals(startTag))
                            if (busLineInfo != null)
                                busLineInfo.setCrowded(xmlPullParser.nextText());


                        if ("nodeId".equals(startTag))
                            if (busLineInfo != null)
                                busLineInfo.setNodeId(xmlPullParser.nextText());


                        break;
                    case XmlPullParser.END_TAG:
                        String endTag = xmlPullParser.getName().trim();
                        if ("item".equals(endTag)) allList.add(busLineInfo);
                        break;
                }
                eventType = xmlPullParser.next();
            }

        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e) {
            e.printStackTrace();
        }

        return allList;
    }
/*ui를 실시간으로 변경 해주는 파싱 이나 백그라운드에서는 돌아가지 않아서 주석 처리 나중에 쓰일수도..
    public ArrayList<BusLineInfoBean> xmlPaserAlarm() throws UnsupportedEncodingException {
        Intent intent = new Intent(this.getIntent());
        String lineId = intent.getStringExtra("lineid");
        ArrayList<BusLineInfoBean> allList = new ArrayList<BusLineInfoBean>();

        String URLSTRING = URLEncoder.encode(lineId, "UTF-8");
        try {
            String key = "http://61.43.246.153/openapi-data/service/busanBIMS2/busInfoRoute?serviceKey=qtoPVWzzOaHE2p0loY9qiyWjAqQ%2FHPfkE3dZmm41%2FLOt9EBf3wB613JruaP8d27Jm0cJlwJE851k7v5UTG4hQQ%3D%3D&lineid="
                    + URLSTRING + " ";
            URL url = new URL(key);
            InputStream inputStream = url.openStream();
            XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
            XmlPullParser xmlPullParser = factory.newPullParser();
            xmlPullParser.setInput(new InputStreamReader(inputStream, "UTF-8"));
            int eventType = xmlPullParser.getEventType();
            BusLineInfoBean busLineInfo = null;
            while (eventType != XmlPullParser.END_DOCUMENT) {
                switch (eventType) {
                    case XmlPullParser.START_TAG:
                        String startTag = xmlPullParser.getName().trim();
                        if ("item".equals(startTag)) busLineInfo = new BusLineInfoBean();

                        if ("bstopIdx".equals(startTag))
                            if (busLineInfo != null)
                                busLineInfo.setBstopIdx(xmlPullParser.nextText());

                        if ("bstopnm".equals(startTag))
                            if (busLineInfo != null)
                                busLineInfo.setBstopnm(xmlPullParser.nextText());

                        if ("carNo".equals(startTag))
                            if (busLineInfo != null) {
                                busLineInfo.setCarNo(xmlPullParser.nextText());
                                if (busLineInfo.getCarNo().equals(busAlarm.getCarno())) {
                                    if (busLineInfo.getBstopIdx().equals(busAlarm.getBstopArrive())) {
                                        Log.i(busAlarm.getBstopArrive(), "Alarm~~: 뿌우우~~~~~~");
                                        NotificationSomethings();
                                    }
                                }
                                int crowdedTest = (int) (Math.random() * 45);
                                String crowded = null;
                                if (crowdedTest < 20) {
                                    crowded = "   [쾌적]";
                                } else if (crowdedTest < 30) {
                                    crowded = "   [보통]";
                                } else {
                                    crowded = "   [혼잡]";
                                }
                                busLineInfo.setCrowded(crowded);

                            }
                        if ("crowded".equals(startTag))
                            if (busLineInfo != null)
                                busLineInfo.setCrowded(xmlPullParser.nextText());

                        break;
                    case XmlPullParser.END_TAG:
                        String endTag = xmlPullParser.getName().trim();
                        if ("item".equals(endTag)) allList.add(busLineInfo);
                        break;
                }
                eventType = xmlPullParser.next();
            }

        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e) {
            e.printStackTrace();
        }

        return allList;
    }

    public ArrayList<BusLineInfoBean> xmlPaserThirdAlarm() throws UnsupportedEncodingException {
        Intent intent = new Intent(this.getIntent());
        String lineId = intent.getStringExtra("lineid");
        ArrayList<BusLineInfoBean> allList = new ArrayList<BusLineInfoBean>();

        String URLSTRING = URLEncoder.encode(lineId, "UTF-8");
        try {
            String key = "http://61.43.246.153/openapi-data/service/busanBIMS2/busInfoRoute?serviceKey=qtoPVWzzOaHE2p0loY9qiyWjAqQ%2FHPfkE3dZmm41%2FLOt9EBf3wB613JruaP8d27Jm0cJlwJE851k7v5UTG4hQQ%3D%3D&lineid="
                    + URLSTRING + " ";
            URL url = new URL(key);
            InputStream inputStream = url.openStream();
            XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
            XmlPullParser xmlPullParser = factory.newPullParser();
            xmlPullParser.setInput(new InputStreamReader(inputStream, "UTF-8"));
            int eventType = xmlPullParser.getEventType();
            BusLineInfoBean busLineInfo = null;
            while (eventType != XmlPullParser.END_DOCUMENT) {
                switch (eventType) {
                    case XmlPullParser.START_TAG:
                        String startTag = xmlPullParser.getName().trim();
                        if ("item".equals(startTag)) busLineInfo = new BusLineInfoBean();

                        if ("bstopIdx".equals(startTag))
                            if (busLineInfo != null)
                                busLineInfo.setBstopIdx(xmlPullParser.nextText());

                        if ("bstopnm".equals(startTag))
                            if (busLineInfo != null)
                                busLineInfo.setBstopnm(xmlPullParser.nextText());

                        if ("carNo".equals(startTag))
                            if (busLineInfo != null) {
                                busLineInfo.setCarNo(xmlPullParser.nextText());

                                if (busLineInfo.getBstopIdx().equals(busAlarm.getBstopArrive())) {
                                    Log.i(busAlarm.getBstopArrive(), "Alarm~~: 뿌우우~~~~~~");
                                    NotificationSomethings();
                                }

                                int crowdedTest = (int) (Math.random() * 45);
                                String crowded = null;
                                if (crowdedTest < 20) {
                                    crowded = "   [쾌적]";
                                } else if (crowdedTest < 30) {
                                    crowded = "   [보통]";
                                } else {
                                    crowded = "   [혼잡]";
                                }
                                busLineInfo.setCrowded(crowded);

                            }
                        if ("crowded".equals(startTag))
                            if (busLineInfo != null)
                                busLineInfo.setCrowded(xmlPullParser.nextText());

                        break;
                    case XmlPullParser.END_TAG:
                        String endTag = xmlPullParser.getName().trim();
                        if ("item".equals(endTag)) allList.add(busLineInfo);
                        break;
                }
                eventType = xmlPullParser.next();
            }

        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e) {
            e.printStackTrace();
        }

        return allList;
    }

    public void NotificationSomethings() {

        Resources res = getResources();

        Intent notificationIntent = new Intent(this, NotificationSomething.class);
        notificationIntent.putExtra("notificationId", 9999); //전달할 값
        PendingIntent contentIntent = PendingIntent.getActivity(this, 0, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this);

        builder.setContentTitle("버스 왔습니다 형님")
                .setContentText("버스 왔어요 뿌~~~~~")
                .setTicker("버스 왔어요 뿌~~~~~")
                .setSmallIcon(R.drawable.busmake)
                .setLargeIcon(BitmapFactory.decodeResource(res, R.drawable.prometheus_bro_icon))
                .setContentIntent(contentIntent)
                .setAutoCancel(true)
                .setWhen(System.currentTimeMillis())
                .setDefaults(Notification.DEFAULT_ALL);


        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
            builder.setCategory(Notification.CATEGORY_MESSAGE)
                    .setPriority(Notification.PRIORITY_HIGH)
                    .setVisibility(Notification.VISIBILITY_PUBLIC);
        }

        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        nm.notify(1234, builder.build());


    }
*/

   class Task extends AsyncTask<Map<String, String>, Integer, String> {

        public String ip = "192.168.0.91"; // 자신의 IP주소를 쓰시면 됩니다.

       @Override
        protected String doInBackground(Map<String, String>... maps) { // 내가 전송하고 싶은 파라미터

            // Http 요청 준비 작업

            HttpClient.Builder http = new HttpClient.Builder
                    ("POST", "http://" + ip + ":8080/prometheus/andtest"); //포트번호,서블릿주소

            // Parameter 를 전송한다.
            http.addAllParameters(maps[0]);

            //Http 요청 전송
            HttpClient post = http.create();
            post.request();

            // 응답 상태코드 가져오기
            int statusCode = post.getHttpStatusCode();

            // 응답 본문 가져오기
            String body = post.getBody();

            return body;
        }
    }
}


