package com.present.bong.bus_evolution;

//버스 노선 빈
public class BusLineInfoBean {
    String bstopIdx;
    String bstopnm;
    String carNo;
    String crowded;
    String nodeId;

    public String getBstopIdx() {
        return bstopIdx;
    }

    public void setBstopIdx(String bstopIdx) {
        this.bstopIdx = bstopIdx;
    }

    public String getBstopnm() {
        return bstopnm;
    }

    public void setBstopnm(String bstopnm) {
        this.bstopnm = bstopnm;
    }

    public String getCarNo() {
        return carNo;
    }

    public void setCarNo(String carNo) {
        this.carNo = carNo;
    }

    public String getCrowded() {
        return crowded;
    }

    public void setCrowded(String crowded) {
        this.crowded = crowded;
    }

    public String getNodeId() { return nodeId; }

    public void setNodeId(String nodeId) { this.nodeId = nodeId; }
}
