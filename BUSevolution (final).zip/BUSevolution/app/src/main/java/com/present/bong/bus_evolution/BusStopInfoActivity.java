package com.present.bong.bus_evolution;


import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.ViewGroup;
import android.widget.ListView;

import com.google.gson.Gson;

import net.daum.mf.map.api.MapPOIItem;
import net.daum.mf.map.api.MapPoint;
import net.daum.mf.map.api.MapView;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

//버스정류장 상세정보 액티비티
public class BusStopInfoActivity extends Activity {
    ListView BusStationInfoListView;
    ArrayList<BusStopInfoBean> busStopInfoList;
    MyCustomBusStopInfoAPIAdapter myCustomBusStopInfoAPIAdapter;
    CrowdedBean crowdedStopdata = new CrowdedBean();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bus_stop_info);

        Intent intent = new Intent(this.getIntent());
        String s = intent.getStringExtra("text");
        String busGpsx = intent.getStringExtra("textX");
        String busGpsY = intent.getStringExtra("textY");

        double gpsx = Double.parseDouble(busGpsx);
        double gpsy = Double.parseDouble(busGpsY);
        //다음 맵을 사용 하기 위하여 맵뷰 객체 사용 Libs에다가 다음 jar파일을 넣고 추가해준다. jinLibs등 gradle 추가.
        MapView mapView = new MapView(this);
        ViewGroup mapViewContainer = (ViewGroup) findViewById(R.id.map_view);
        mapView.setMapCenterPoint(MapPoint.mapPointWithGeoCoord(gpsy, gpsx), true);

        mapViewContainer.addView(mapView);
        MapPOIItem marker = new MapPOIItem();
        marker.setItemName(s);
        marker.setTag(0);
        marker.setMapPoint(MapPoint.mapPointWithGeoCoord(gpsy, gpsx));
        marker.setMarkerType(MapPOIItem.MarkerType.BluePin);
        marker.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin);

        mapView.addPOIItem(marker);
        send();
        BusStationInfoListView = (ListView) findViewById(R.id.busStopInfoList);

    }

    //파싱 쓰레드
    public void send() {
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    busStopInfoList = xmlPaser();
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        myCustomBusStopInfoAPIAdapter =
                                new MyCustomBusStopInfoAPIAdapter(getApplicationContext(),
                                        R.layout.bus_stop_info_list_row, busStopInfoList);
                        BusStationInfoListView.setAdapter(myCustomBusStopInfoAPIAdapter);
                    }
                });
            }
        });
        thread.start();
    }

    //파싱 메소드
    public ArrayList<BusStopInfoBean> xmlPaser() throws UnsupportedEncodingException {
        Intent intent = new Intent(this.getIntent());
        String busId = intent.getStringExtra("textId");
        ArrayList<BusStopInfoBean> allList = new ArrayList<BusStopInfoBean>();

        String URLSTRING = URLEncoder.encode(busId, "UTF-8");
        try {
            String key = "http://61.43.246.153/openapi-data/service/busanBIMS2/stopArr?serviceKey=qtoPVWzzOaHE2p0loY9qiyWjAqQ%2FHPfkE3dZmm41%2FLOt9EBf3wB613JruaP8d27Jm0cJlwJE851k7v5UTG4hQQ%3D%3D&bstopid="
                    + URLSTRING + " ";
            URL url = new URL(key);
            InputStream inputStream = url.openStream();
            XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
            XmlPullParser xmlPullParser = factory.newPullParser();
            xmlPullParser.setInput(new InputStreamReader(inputStream, "UTF-8"));
            int eventType = xmlPullParser.getEventType();
            BusStopInfoBean busStopInfo = null;
            while (eventType != XmlPullParser.END_DOCUMENT) {
                switch (eventType) {
                    case XmlPullParser.START_TAG:
                        String startTag = xmlPullParser.getName().trim();
                        if ("item".equals(startTag)) busStopInfo = new BusStopInfoBean();

                        if ("lineNo".equals(startTag))
                            if (busStopInfo != null)
                                busStopInfo.setLineNo(xmlPullParser.nextText());

                        if ("carNo1".equals(startTag))
                            if (busStopInfo != null) {
                                busStopInfo.setCarNo1(xmlPullParser.nextText());
                                if (busStopInfo.getCarNo1().equals("운행중버스")) {
                                    try {
                                        TaskStop networkTaskStop = new TaskStop();

                                        Map<String, String> params = new HashMap<String, String>();
                                        params.put("carno", "2632");
                                        String test =  networkTaskStop.execute(params).get();
                                        Gson gson = new Gson();
                                        crowdedStopdata = gson.fromJson(test, CrowdedBean.class);
                                        int crowdedTest = crowdedStopdata.getCrowded();

                                        Log.i("xammlpas", "crowdedTest: "+crowdedTest);
                                        String crowded = null;
                                        if (crowdedTest < 20) {
                                            crowded = "[쾌적]";
                                        } else if (crowdedTest < 30) {
                                            crowded = "[보통]";
                                        } else {
                                            crowded = "[혼잡]";
                                        }
                                        busStopInfo.setCrowded1(crowded);
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }

                                } else {
                                    int crowdedTest = (int) (Math.random() * 45);
                                    String crowded = null;
                                    if (crowdedTest < 20) {
                                        crowded = "[쾌적]";
                                    } else if (crowdedTest < 30) {
                                        crowded = "[보통]";
                                    } else {
                                        crowded = "[혼잡]";
                                    }
                                    busStopInfo.setCrowded1(crowded);
                                }
                            }

                        if ("station1".equals(startTag))
                            if (busStopInfo != null)
                                busStopInfo.setStation1("  " + xmlPullParser.nextText() + "정거장전  ");

                        if ("min1".equals(startTag))
                            if (busStopInfo != null)
                                busStopInfo.setMin1(xmlPullParser.nextText() + "분후도착  ");

                        if ("crowded1".equals(startTag))
                            if (busStopInfo != null)
                                busStopInfo.setCrowded1(xmlPullParser.nextText());

                        if ("carNo2".equals(startTag))
                            if (busStopInfo != null) {
                                busStopInfo.setCarNo2(xmlPullParser.nextText());

                                int crowdedTest = (int) (Math.random() * 45);
                                String crowded = null;
                                if (crowdedTest < 20) {
                                    crowded = "[쾌적]";
                                } else if (crowdedTest < 30) {
                                    crowded = "[보통]";
                                } else {
                                    crowded = "[혼잡]";
                                }
                                busStopInfo.setCrowded2(crowded);

                            }

                        if ("station2".equals(startTag))
                            if (busStopInfo != null)
                                busStopInfo.setStation2("  " + xmlPullParser.nextText() + "정거장전  ");

                        if ("min2".equals(startTag))
                            if (busStopInfo != null)
                                busStopInfo.setMin2(xmlPullParser.nextText() + "분후도착  ");

                        if ("crowded2".equals(startTag))
                            if (busStopInfo != null)
                                busStopInfo.setCrowded2(xmlPullParser.nextText());

                        break;
                    case XmlPullParser.END_TAG:
                        String endTag = xmlPullParser.getName().trim();
                        if ("item".equals(endTag)) allList.add(busStopInfo);
                        break;
                }
                eventType = xmlPullParser.next();
            }

        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e) {
            e.printStackTrace();
        }

        return allList;
    }
    class TaskStop extends AsyncTask<Map<String, String>, Integer, String> {

        public String ip = "192.168.0.91"; // 자신의 IP주소를 쓰시면 됩니다.

        @Override
        protected String doInBackground(Map<String, String>... maps) { // 내가 전송하고 싶은 파라미터

            // Http 요청 준비 작업

            HttpClient.Builder http = new HttpClient.Builder
                    ("POST", "http://" + ip + ":8080/prometheus/andtest"); //포트번호,서블릿주소

            // Parameter 를 전송한다.
            http.addAllParameters(maps[0]);

            //Http 요청 전송
            HttpClient post = http.create();
            post.request();

            // 응답 상태코드 가져오기
            int statusCode = post.getHttpStatusCode();

            // 응답 본문 가져오기
            String body = post.getBody();
            //execute 로 값을 보냈을때 get을 쓰면 Body값을 가져 올수 있다. 가져온 Body값을 jSon변환 해서 넣은 빈 을 사용가능.
            return body;
        }
    }
}
